require("./eleventy-app-config-modules.js");
require("./eleventy-app-globaldata-modules.js");
require("./eleventy-app-dirdata-modules.js");